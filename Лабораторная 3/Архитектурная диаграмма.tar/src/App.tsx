import { useState } from 'react';
import UseCaseDiagram from './components/UseCaseDiagram';
import ArchitectureDiagram from './components/ArchitectureDiagram';
import Legend from './components/Legend';
import ArchitectureLegend from './components/ArchitectureLegend';
import InfoPanel from './components/InfoPanel';
import ArchitectureInfoPanel from './components/ArchitectureInfoPanel';

type DiagramType = 'usecase' | 'architecture';

export default function App() {
  const [activeDiagram, setActiveDiagram] = useState<DiagramType>('usecase');
  const [selectedElement, setSelectedElement] = useState<string | null>(null);

  const handleDiagramChange = (diagram: DiagramType) => {
    setActiveDiagram(diagram);
    setSelectedElement(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">UML-диаграммы</h1>
                <p className="text-sm text-slate-400">Автоматизированная система записи к врачу</p>
              </div>
            </div>

            {/* Tab navigation */}
            <div className="flex bg-slate-800/50 rounded-lg p-1 border border-slate-700/50">
              <button
                onClick={() => handleDiagramChange('usecase')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeDiagram === 'usecase'
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                  Use Case
                </span>
              </button>
              <button
                onClick={() => handleDiagramChange('architecture')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeDiagram === 'architecture'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  Архитектура
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Diagram Area */}
          <div className="lg:col-span-3">
            <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 backdrop-blur-sm">
              {activeDiagram === 'usecase' ? (
                <UseCaseDiagram
                  selectedElement={selectedElement}
                  onSelectElement={setSelectedElement}
                />
              ) : (
                <ArchitectureDiagram
                  selectedElement={selectedElement}
                  onSelectElement={setSelectedElement}
                />
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {activeDiagram === 'usecase' ? (
              <>
                <InfoPanel selectedElement={selectedElement} />
                <Legend />
              </>
            ) : (
              <>
                <ArchitectureInfoPanel selectedElement={selectedElement} />
                <ArchitectureLegend />
              </>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700/50 mt-8">
        <div className="max-w-7xl mx-auto px-4 py-4 text-center text-sm text-slate-500">
          UML-диаграммы • Система записи к врачу • 2026
        </div>
      </footer>
    </div>
  );
}
