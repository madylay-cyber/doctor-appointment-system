export default function ArchitectureLegend() {
  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 backdrop-blur-sm">
      <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        Легенда
      </h3>
      <div className="space-y-3">
        {/* Layer colors */}
        <div>
          <p className="text-xs text-slate-500 mb-2">Слои архитектуры:</p>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded border-2 border-dashed" style={{ borderColor: '#ec4899', backgroundColor: 'rgba(236, 72, 153, 0.1)' }}></div>
              <span className="text-xs text-slate-400">Presentation Layer</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded border-2 border-dashed" style={{ borderColor: '#8b5cf6', backgroundColor: 'rgba(139, 92, 246, 0.1)' }}></div>
              <span className="text-xs text-slate-400">Service Layer</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded border-2 border-dashed" style={{ borderColor: '#f59e0b', backgroundColor: 'rgba(245, 158, 11, 0.1)' }}></div>
              <span className="text-xs text-slate-400">Repository Layer</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded border-2 border-dashed" style={{ borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)' }}></div>
              <span className="text-xs text-slate-400">Database Layer</span>
            </div>
          </div>
        </div>

        {/* Components */}
        <div className="pt-2 border-t border-slate-700/50">
          <p className="text-xs text-slate-500 mb-2">Компоненты:</p>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-4 rounded border border-slate-500 bg-slate-700/50"></div>
              <span className="text-xs text-slate-400">Компонент / Сервис</span>
            </div>
            <div className="flex items-center gap-2">
              <svg viewBox="0 0 30 20" className="w-6 h-4">
                <ellipse cx="15" cy="5" rx="13" ry="4" fill="none" stroke="#3b82f6" strokeWidth="1.5" />
                <path d="M 2 5 L 2 15 Q 2 19, 15 19 Q 28 19, 28 15 L 28 5" fill="none" stroke="#3b82f6" strokeWidth="1.5" />
              </svg>
              <span className="text-xs text-slate-400">База данных</span>
            </div>
          </div>
        </div>

        {/* Flow */}
        <div className="pt-2 border-t border-slate-700/50">
          <p className="text-xs text-slate-500 mb-2">Поток данных:</p>
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 40 10" className="w-8 h-3">
              <line x1="2" y1="5" x2="32" y2="5" stroke="#60a5fa" strokeWidth="1.5" />
              <polygon points="32,2 38,5 32,8" fill="#60a5fa" />
            </svg>
            <span className="text-xs text-slate-400">Направление запроса</span>
          </div>
        </div>

        {/* Description */}
        <div className="pt-2 border-t border-slate-700/50">
          <p className="text-xs text-slate-500 leading-relaxed">
            Диаграмма показывает жизненный цикл запроса «Запись на прием» через все 4 слоя системы.
          </p>
        </div>
      </div>
    </div>
  );
}
