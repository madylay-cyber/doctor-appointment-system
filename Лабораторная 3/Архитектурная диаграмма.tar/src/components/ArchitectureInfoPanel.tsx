interface Props {
  selectedElement: string | null;
}

interface ElementInfo {
  title: string;
  type: string;
  description: string;
  details?: string[];
}

const elementData: Record<string, ElementInfo> = {
  client: {
    title: 'Клиент: Браузер / ЛК Пациента',
    type: 'Компонент Presentation Layer',
    description: 'Фронтенд-приложение, через которое пациент инициирует запрос на запись. Отправляет HTTP-запрос к API.',
    details: [
      'Инициирует POST /api/v1/appointments/book',
      'Отправляет JSON с данными записи',
      'Получает ответ от сервера',
    ],
  },
  controller: {
    title: 'AppointmentController',
    type: 'Контроллер (Presentation Layer)',
    description: 'Принимает HTTP-запрос, валидирует входные данные по JSON-схеме и передаёт управление в сервисный слой.',
    details: [
      'Шаг 1: Получение POST-запроса',
      'Шаг 2: Валидация JSON-схемы',
      'Шаг 3: Вызов метода book_appointment()',
    ],
  },
  service: {
    title: 'AppointmentService',
    type: 'Сервис (Service Layer)',
    description: 'Содержит бизнес-логику. Проверяет правила: отсутствие конфликтов слотов, корректность времени, доступность врача.',
    details: [
      'Шаг 3: Получение вызова от контроллера',
      'Шаг 4: Проверка бизнес-правил',
      'Шаг 5: Запрос доступности слота из репозитория',
    ],
  },
  repository: {
    title: 'AppointmentRepository',
    type: 'Репозиторий (Repository Layer)',
    description: 'Инкапсулирует работу с данными. Формирует SQL-запросы и обеспечивает абстракцию от конкретной СУБД.',
    details: [
      'Шаг 5: Получение запроса от сервиса',
      'Шаг 6: SELECT FROM slots WHERE...',
      'Шаг 7: Получение результата из БД',
      'Шаг 8: save_appointment()',
      'Шаг 9: INSERT INTO appointments',
    ],
  },
  database: {
    title: 'Медицинская БД (PostgreSQL)',
    type: 'База данных (Database Layer)',
    description: 'Персистентное хранилище данных. Содержит таблицы слотов, записей, пациентов и врачей.',
    details: [
      'Шаг 6: Обработка SELECT-запроса',
      'Шаг 7: Возврат результата (слот свободен/занят)',
      'Шаг 9: Выполнение INSERT-запроса',
    ],
  },
};

export default function ArchitectureInfoPanel({ selectedElement }: Props) {
  const info = selectedElement ? elementData[selectedElement] : null;

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 backdrop-blur-sm">
      <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
        </svg>
        Компонент
      </h3>

      {info ? (
        <div className="space-y-3">
          <div>
            <span className="inline-block px-2 py-0.5 text-xs rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 mb-2">
              {info.type}
            </span>
            <h4 className="text-base font-semibold text-white">{info.title}</h4>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed">{info.description}</p>
          {info.details && info.details.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-1.5">Этапы взаимодействия:</p>
              <ul className="space-y-1">
                {info.details.map((detail, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                    <span className="text-blue-400 mt-0.5">▸</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-6">
          <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-slate-700/50 flex items-center justify-center">
            <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
            </svg>
          </div>
          <p className="text-sm text-slate-500">Нажмите на компонент диаграммы для просмотра подробностей</p>
        </div>
      )}
    </div>
  );
}
