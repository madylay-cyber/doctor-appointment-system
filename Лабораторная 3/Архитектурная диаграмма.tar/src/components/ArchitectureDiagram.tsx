import { useState } from 'react';

interface Props {
  selectedElement: string | null;
  onSelectElement: (id: string | null) => void;
}

interface Layer {
  id: string;
  title: string;
  subtitle: string;
  y: number;
  color: string;
  bgColor: string;
}

interface Component {
  id: string;
  label: string;
  x: number;
  y: number;
  layerId: string;
  type: 'client' | 'controller' | 'service' | 'repository' | 'database';
}

const layers: Layer[] = [
  {
    id: 'presentation',
    title: '1. Presentation Layer',
    subtitle: 'app/api',
    y: 40,
    color: '#ec4899',
    bgColor: 'rgba(236, 72, 153, 0.1)',
  },
  {
    id: 'service',
    title: '2. Service Layer',
    subtitle: 'app/services',
    y: 220,
    color: '#8b5cf6',
    bgColor: 'rgba(139, 92, 246, 0.1)',
  },
  {
    id: 'repository',
    title: '3. Repository Layer',
    subtitle: 'app/repositories',
    y: 400,
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.1)',
  },
  {
    id: 'database',
    title: '4. Database Layer',
    subtitle: 'PostgreSQL',
    y: 580,
    color: '#3b82f6',
    bgColor: 'rgba(59, 130, 246, 0.1)',
  },
];

const components: Component[] = [
  { id: 'client', label: 'Клиент: Браузер / ЛК Пациента', x: 150, y: 110, layerId: 'presentation', type: 'client' },
  { id: 'controller', label: 'AppointmentController', x: 550, y: 110, layerId: 'presentation', type: 'controller' },
  { id: 'service', label: 'AppointmentService', x: 550, y: 290, layerId: 'service', type: 'service' },
  { id: 'repository', label: 'AppointmentRepository', x: 550, y: 470, layerId: 'repository', type: 'repository' },
  { id: 'database', label: 'Медицинская БД', x: 550, y: 650, layerId: 'database', type: 'database' },
];

interface FlowStep {
  id: string;
  from: string;
  to: string;
  label: string;
  stepNumber: number;
}

const flowSteps: FlowStep[] = [
  { id: 'step1', from: 'client', to: 'controller', label: 'POST /api/v1/appointments/book', stepNumber: 1 },
  { id: 'step2', from: 'controller', to: 'controller', label: 'Валидация схемы JSON', stepNumber: 2 },
  { id: 'step3', from: 'controller', to: 'service', label: 'book_appointment()', stepNumber: 3 },
  { id: 'step4', from: 'service', to: 'service', label: 'Проверка бизнес-правил', stepNumber: 4 },
  { id: 'step5', from: 'service', to: 'repository', label: 'Запрос доступности слота', stepNumber: 5 },
  { id: 'step6', from: 'repository', to: 'database', label: 'SELECT FROM slots WHERE...', stepNumber: 6 },
  { id: 'step7', from: 'database', to: 'repository', label: 'Слот свободен', stepNumber: 7 },
  { id: 'step8', from: 'repository', to: 'repository', label: 'save_appointment()', stepNumber: 8 },
  { id: 'step9', from: 'repository', to: 'database', label: 'INSERT INTO appointments', stepNumber: 9 },
];

function getComponent(id: string): Component | undefined {
  return components.find(c => c.id === id);
}

function getComponentPosition(id: string): { x: number; y: number } {
  const comp = getComponent(id);
  if (!comp) return { x: 0, y: 0 };
  return { x: comp.x, y: comp.y };
}

export default function ArchitectureDiagram({ selectedElement, onSelectElement }: Props) {
  const [hoveredElement, setHoveredElement] = useState<string | null>(null);
  const activeElement = hoveredElement || selectedElement;

  const svgWidth = 800;
  const svgHeight = 760;

  return (
    <div className="overflow-x-auto">
      <svg
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        className="w-full min-w-[600px]"
        style={{ maxHeight: '85vh' }}
      >
        <defs>
          <marker id="arrow-flow" viewBox="0 0 10 10" refX="10" refY="5"
            markerWidth="8" markerHeight="8" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#60a5fa" />
          </marker>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Layers */}
        {layers.map(layer => (
          <g key={layer.id}>
            <rect
              x="20"
              y={layer.y}
              width="760"
              height="160"
              rx="12"
              ry="12"
              fill={layer.bgColor}
              stroke={layer.color}
              strokeWidth="2"
              strokeDasharray="8 4"
            />
            <text x="40" y={layer.y + 30} fill={layer.color} fontSize="16" fontWeight="bold">
              {layer.title}
            </text>
            <text x="40" y={layer.y + 50} fill="#94a3b8" fontSize="12">
              ({layer.subtitle})
            </text>
          </g>
        ))}

        {/* Flow arrows */}
        {flowSteps.map((step, i) => {
          const from = getComponentPosition(step.from);
          const to = getComponentPosition(step.to);
          const isActive = activeElement === step.id || activeElement === step.from || activeElement === step.to;
          
          // Self-loops
          if (step.from === step.to) {
            const comp = getComponent(step.from);
            if (!comp) return null;
            const loopRadius = 30;
            const loopX = comp.x + (comp.type === 'client' ? 120 : 100);
            return (
              <g key={step.id} opacity={activeElement && !isActive ? 0.3 : 1}>
                <path
                  d={`M ${comp.x + 80} ${comp.y - 10} 
                      Q ${loopX} ${comp.y - 10}, ${loopX} ${comp.y}
                      Q ${loopX} ${comp.y + 10}, ${comp.x + 80} ${comp.y + 10}`}
                  fill="none"
                  stroke="#60a5fa"
                  strokeWidth={isActive ? 2.5 : 1.5}
                  markerEnd="url(#arrow-flow)"
                />
                <text x={loopX + 10} y={comp.y} fill="#60a5fa" fontSize="10" textAnchor="start">
                  {step.stepNumber}. {step.label}
                </text>
              </g>
            );
          }

          // Regular arrows
          const isDownward = from.y < to.y;
          const isUpward = from.y > to.y;
          
          let path;
          if (isDownward) {
            path = `M ${from.x} ${from.y + 25} L ${to.x} ${to.y - 25}`;
          } else if (isUpward) {
            path = `M ${from.x - 30} ${from.y - 25} L ${to.x - 30} ${to.y + 25}`;
          } else {
            path = `M ${from.x + 80} ${from.y} L ${to.x - 80} ${to.y}`;
          }

          const midX = (from.x + to.x) / 2;
          const midY = (from.y + to.y) / 2;

          return (
            <g key={step.id} opacity={activeElement && !isActive ? 0.3 : 1}>
              <path
                d={path}
                fill="none"
                stroke="#60a5fa"
                strokeWidth={isActive ? 2.5 : 1.5}
                markerEnd="url(#arrow-flow)"
              />
              <text x={midX + (isUpward ? -50 : 10)} y={midY} fill="#60a5fa" fontSize="10" textAnchor="start">
                {step.stepNumber}. {step.label}
              </text>
            </g>
          );
        })}

        {/* Components */}
        {components.map(comp => {
          const isActive = activeElement === comp.id;
          const layer = layers.find(l => l.id === comp.layerId);
          const color = layer?.color || '#6b7280';

          let shape;
          if (comp.type === 'database') {
            // Database cylinder
            shape = (
              <g>
                <ellipse cx={comp.x} cy={comp.y - 20} rx="80" ry="15" fill={`${color}33`} stroke={color} strokeWidth={isActive ? 2.5 : 1.5} />
                <path
                  d={`M ${comp.x - 80} ${comp.y - 20} L ${comp.x - 80} ${comp.y + 20} 
                      Q ${comp.x - 80} ${comp.y + 35}, ${comp.x} ${comp.y + 35}
                      Q ${comp.x + 80} ${comp.y + 35}, ${comp.x + 80} ${comp.y + 20}
                      L ${comp.x + 80} ${comp.y - 20}`}
                  fill={`${color}33`}
                  stroke={color}
                  strokeWidth={isActive ? 2.5 : 1.5}
                />
                <ellipse cx={comp.x} cy={comp.y - 20} rx="80" ry="15" fill={`${color}33`} stroke={color} strokeWidth={isActive ? 2.5 : 1.5} />
              </g>
            );
          } else {
            // Rectangle for other components
            shape = (
              <rect
                x={comp.x - 80}
                y={comp.y - 25}
                width="160"
                height="50"
                rx="8"
                ry="8"
                fill={isActive ? `${color}44` : `${color}22`}
                stroke={color}
                strokeWidth={isActive ? 2.5 : 1.5}
                filter={isActive ? 'url(#glow)' : undefined}
              />
            );
          }

          return (
            <g
              key={comp.id}
              onClick={() => onSelectElement(comp.id === selectedElement ? null : comp.id)}
              onMouseEnter={() => setHoveredElement(comp.id)}
              onMouseLeave={() => setHoveredElement(null)}
              className="cursor-pointer"
              opacity={activeElement && !isActive ? 0.4 : 1}
            >
              {shape}
              <text
                x={comp.x}
                y={comp.y + (comp.type === 'database' ? 5 : 5)}
                textAnchor="middle"
                fill="white"
                fontSize="13"
                fontWeight={isActive ? 'bold' : 'normal'}
              >
                {comp.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
