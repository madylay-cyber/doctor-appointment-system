export default function Legend() {
  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 backdrop-blur-sm">
      <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        Легенда
      </h3>
      <div className="space-y-3">
        {/* Actors */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <svg viewBox="0 0 30 50" className="w-5 h-7">
              <circle cx="15" cy="8" r="6" fill="none" stroke="#e2e8f0" strokeWidth="2" />
              <line x1="15" y1="14" x2="15" y2="30" stroke="#e2e8f0" strokeWidth="2" />
              <line x1="5" y1="22" x2="25" y2="22" stroke="#e2e8f0" strokeWidth="2" />
              <line x1="15" y1="30" x2="5" y2="45" stroke="#e2e8f0" strokeWidth="2" />
              <line x1="15" y1="30" x2="25" y2="45" stroke="#e2e8f0" strokeWidth="2" />
            </svg>
          </div>
          <span className="text-xs text-slate-400">Актор (роль)</span>
        </div>

        {/* Use Case */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <svg viewBox="0 0 40 24" className="w-8 h-5">
              <ellipse cx="20" cy="12" rx="18" ry="10" fill="rgba(30,41,59,0.8)" stroke="#3b82f6" strokeWidth="1.5" />
            </svg>
          </div>
          <span className="text-xs text-slate-400">Вариант использования</span>
        </div>

        {/* Association */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <svg viewBox="0 0 40 10" className="w-8 h-3">
              <line x1="2" y1="5" x2="38" y2="5" stroke="#475569" strokeWidth="1.5" />
            </svg>
          </div>
          <span className="text-xs text-slate-400">Ассоциация</span>
        </div>

        {/* Include */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <svg viewBox="0 0 40 10" className="w-8 h-3">
              <line x1="2" y1="5" x2="32" y2="5" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 2" />
              <polygon points="32,2 38,5 32,8" fill="#94a3b8" />
            </svg>
          </div>
          <span className="text-xs text-slate-400">«include»</span>
        </div>

        {/* Extend */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <svg viewBox="0 0 40 10" className="w-8 h-3">
              <line x1="2" y1="5" x2="32" y2="5" stroke="#a78bfa" strokeWidth="1.5" strokeDasharray="4 2" />
              <polygon points="32,2 38,5 32,8" fill="#a78bfa" />
            </svg>
          </div>
          <span className="text-xs text-slate-400">«extend»</span>
        </div>

        {/* Group colors */}
        <div className="pt-2 border-t border-slate-700/50">
          <p className="text-xs text-slate-500 mb-2">Группы функций:</p>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span className="text-xs text-slate-400">Пациент</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span className="text-xs text-slate-400">Врач</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <span className="text-xs text-slate-400">Администратор</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500"></div>
              <span className="text-xs text-slate-400">Менеджер системы</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
