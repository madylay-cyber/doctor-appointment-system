interface Props {
  selectedElement: string | null;
}

interface ElementInfo {
  title: string;
  type: 'actor' | 'usecase';
  description: string;
  connections?: string[];
}

const elementData: Record<string, ElementInfo> = {
  // Actors
  patient: {
    title: 'Пациент',
    type: 'actor',
    description: 'Физическое лицо, которое ищет врача, записывается на прием и может отменить или перенести запись.',
    connections: ['Найти врача', 'Записаться на прием', 'Отменить/Перенести запись'],
  },
  doctor: {
    title: 'Врач / Специалист',
    type: 'actor',
    description: 'Медицинский сотрудник, который просматривает свой график, читает карты пациентов и составляет медицинские заключения.',
    connections: ['Посмотреть график', 'Прочитать карту пациента', 'Составить заключение'],
  },
  admin: {
    title: 'Администратор регистратуры',
    type: 'actor',
    description: 'Управленческий персонал, отвечающий за управление расписанием, ведение данных пациентов и формирование отчетности.',
    connections: ['Управлять расписанием', 'Внести данные пациента', 'Формировать отчетность'],
  },
  manager: {
    title: 'Менеджер системы',
    type: 'actor',
    description: 'Системный администратор, ответственный за настройку справочников, категорий услуг и специализаций.',
    connections: ['Настроить справочники'],
  },

  // Use Cases
  'find-doctor': {
    title: 'Найти врача',
    type: 'usecase',
    description: 'Выбор специалиста по специальности, клинике и доступности. Пациент фильтрует врачей по нужным критериям.',
    connections: ['Пациент'],
  },
  'book-appointment': {
    title: 'Записаться на прием',
    type: 'usecase',
    description: 'Бронирование слота в календаре с проверкой уникальности и времени. Включает проверку доступности слота.',
    connections: ['Пациент', '«include» Проверить доступность слота', '«extend» Получить напоминание'],
  },
  'cancel-appointment': {
    title: 'Отменить/Перенести запись',
    type: 'usecase',
    description: 'Изменение статуса записи пользователем. Позволяет отменить или перенести существующую запись на другое время.',
    connections: ['Пациент'],
  },
  'get-reminder': {
    title: 'Получить напоминание',
    type: 'usecase',
    description: 'Опциональное уведомление о предстоящем приеме. Расширяет функцию записи на прием.',
    connections: ['«extend» Записаться на прием'],
  },
  'check-slot': {
    title: 'Проверить доступность слота',
    type: 'usecase',
    description: 'Системная функция проверки, свободно ли выбранное время. Всегда вызывается при записи на прием.',
    connections: ['«include» из: Записаться на прием'],
  },
  'view-schedule': {
    title: 'Посмотреть график',
    type: 'usecase',
    description: 'Просмотр запланированных приемов на текущий день/неделю. Врач видит расписание своих пациентов.',
    connections: ['Врач'],
  },
  'read-card': {
    title: 'Прочитать карту пациента',
    type: 'usecase',
    description: 'Доступ к истории болезни, анамнезу и предыдущим диагнозам пациента перед приемом.',
    connections: ['Врач'],
  },
  'write-conclusion': {
    title: 'Составить заключение',
    type: 'usecase',
    description: 'Ввод данных о проведенном осмотре, диагнозе и назначении лечения. Завершение приема. Включает доступ к карте пациента.',
    connections: ['Врач', '«include» Доступ к карте пациента'],
  },
  'access-card': {
    title: 'Доступ к карте пациента',
    type: 'usecase',
    description: 'Системная функция получения данных медицинской карты. Вызывается при составлении заключения.',
    connections: ['«include» из: Составить заключение'],
  },
  'manage-schedule': {
    title: 'Управлять расписанием',
    type: 'usecase',
    description: 'Блокирование слотов, ручное изменение графика работы врача или кабинета. Административная функция.',
    connections: ['Администратор'],
  },
  'enter-patient-data': {
    title: 'Внести данные пациента',
    type: 'usecase',
    description: 'Создание или редактирование профиля пациента в базе данных. Регистрация нового пациента.',
    connections: ['Администратор'],
  },
  'generate-reports': {
    title: 'Формировать отчетность',
    type: 'usecase',
    description: 'Генерация отчетов по загрузке ресурсов и количеству записей. Аналитическая функция.',
    connections: ['Администратор'],
  },
  'configure-dictionaries': {
    title: 'Настроить справочники',
    type: 'usecase',
    description: 'Управление категориями услуг, специализациями врачей и общим расписанием клиники.',
    connections: ['Менеджер системы'],
  },
};

export default function InfoPanel({ selectedElement }: Props) {
  const info = selectedElement ? elementData[selectedElement] : null;

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 backdrop-blur-sm">
      <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        Информация
      </h3>

      {info ? (
        <div className="space-y-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`inline-block w-2 h-2 rounded-full ${
                info.type === 'actor' ? 'bg-blue-400' : 'bg-emerald-400'
              }`}></span>
              <span className="text-xs text-slate-500 uppercase tracking-wider">
                {info.type === 'actor' ? 'Актор' : 'Вариант использования'}
              </span>
            </div>
            <h4 className="text-base font-semibold text-white">{info.title}</h4>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed">{info.description}</p>
          {info.connections && info.connections.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-1.5">Связи:</p>
              <div className="flex flex-wrap gap-1.5">
                {info.connections.map((conn, i) => (
                  <span
                    key={i}
                    className="inline-block px-2 py-0.5 text-xs rounded-full bg-slate-700/50 text-slate-300 border border-slate-600/50"
                  >
                    {conn}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-6">
          <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-slate-700/50 flex items-center justify-center">
            <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
            </svg>
          </div>
          <p className="text-sm text-slate-500">Нажмите на элемент диаграммы для просмотра подробной информации</p>
        </div>
      )}
    </div>
  );
}
