import { useState } from 'react';

interface Props {
  selectedElement: string | null;
  onSelectElement: (id: string | null) => void;
}

// Data types
interface UseCase {
  id: string;
  label: string;
  cx: number;
  cy: number;
  group: string;
}

interface Actor {
  id: string;
  label: string;
  x: number;
  y: number;
  side: 'left' | 'right';
}

const useCases: UseCase[] = [
  // Patient group
  { id: 'find-doctor', label: 'Найти врача', cx: 480, cy: 120, group: 'patient' },
  { id: 'book-appointment', label: 'Записаться на прием', cx: 480, cy: 220, group: 'patient' },
  { id: 'cancel-appointment', label: 'Отменить/Перенести запись', cx: 480, cy: 320, group: 'patient' },
  { id: 'get-reminder', label: 'Получить напоминание', cx: 680, cy: 170, group: 'patient' },
  { id: 'check-slot', label: 'Проверить доступность слота', cx: 680, cy: 270, group: 'system' },

  // Doctor group
  { id: 'view-schedule', label: 'Посмотреть график', cx: 480, cy: 430, group: 'doctor' },
  { id: 'read-card', label: 'Прочитать карту пациента', cx: 480, cy: 520, group: 'doctor' },
  { id: 'write-conclusion', label: 'Составить заключение', cx: 480, cy: 610, group: 'doctor' },
  { id: 'access-card', label: 'Доступ к карте пациента', cx: 680, cy: 565, group: 'system' },

  // Admin group
  { id: 'manage-schedule', label: 'Управлять расписанием', cx: 480, cy: 720, group: 'admin' },
  { id: 'enter-patient-data', label: 'Внести данные пациента', cx: 480, cy: 810, group: 'admin' },
  { id: 'generate-reports', label: 'Формировать отчетность', cx: 480, cy: 900, group: 'admin' },

  // Manager group
  { id: 'configure-dictionaries', label: 'Настроить справочники', cx: 480, cy: 1000, group: 'manager' },
];

const actors: Actor[] = [
  { id: 'patient', label: 'Пациент', x: 100, y: 220, side: 'left' },
  { id: 'doctor', label: 'Врач', x: 100, y: 520, side: 'left' },
  { id: 'admin', label: 'Администратор', x: 870, y: 810, side: 'right' },
  { id: 'manager', label: 'Менеджер системы', x: 870, y: 1000, side: 'right' },
];

// Associations: actor -> use cases
const associations: { actorId: string; useCaseId: string }[] = [
  { actorId: 'patient', useCaseId: 'find-doctor' },
  { actorId: 'patient', useCaseId: 'book-appointment' },
  { actorId: 'patient', useCaseId: 'cancel-appointment' },
  { actorId: 'doctor', useCaseId: 'view-schedule' },
  { actorId: 'doctor', useCaseId: 'read-card' },
  { actorId: 'doctor', useCaseId: 'write-conclusion' },
  { actorId: 'admin', useCaseId: 'manage-schedule' },
  { actorId: 'admin', useCaseId: 'enter-patient-data' },
  { actorId: 'admin', useCaseId: 'generate-reports' },
  { actorId: 'manager', useCaseId: 'configure-dictionaries' },
];

// Include relationships
const includes: { from: string; to: string }[] = [
  { from: 'book-appointment', to: 'check-slot' },
  { from: 'write-conclusion', to: 'access-card' },
];

// Extend relationships
const extends_: { from: string; to: string }[] = [
  { from: 'get-reminder', to: 'book-appointment' },
];

function getUseCase(id: string): UseCase | undefined {
  return useCases.find(uc => uc.id === id);
}

function getActor(id: string): Actor | undefined {
  return actors.find(a => a.id === id);
}

const groupColors: Record<string, string> = {
  patient: '#3b82f6',
  doctor: '#10b981',
  admin: '#f59e0b',
  manager: '#8b5cf6',
  system: '#6b7280',
};

export default function UseCaseDiagram({ selectedElement, onSelectElement }: Props) {
  const [hoveredElement, setHoveredElement] = useState<string | null>(null);
  const activeElement = hoveredElement || selectedElement;

  const svgWidth = 970;
  const svgHeight = 1080;

  return (
    <div className="overflow-x-auto">
      <svg
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        className="w-full min-w-[700px]"
        style={{ maxHeight: '80vh' }}
      >
        <defs>
          {/* Arrow marker for include */}
          <marker id="arrow-include" viewBox="0 0 10 10" refX="10" refY="5"
            markerWidth="8" markerHeight="8" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" />
          </marker>
          {/* Arrow marker for extend */}
          <marker id="arrow-extend" viewBox="0 0 10 10" refX="10" refY="5"
            markerWidth="8" markerHeight="8" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#a78bfa" />
          </marker>
          {/* Glow filter */}
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* System boundary */}
        <rect
          x="300"
          y="40"
          width="500"
          height="1020"
          rx="16"
          ry="16"
          fill="rgba(30, 41, 59, 0.6)"
          stroke="#475569"
          strokeWidth="2"
          strokeDasharray="8 4"
        />
        <text x="550" y="75" textAnchor="middle" className="text-sm" fill="#94a3b8" fontSize="14" fontWeight="bold">
          Автоматизированная система записи на прием к врачу
        </text>

        {/* Association lines */}
        {associations.map((assoc, i) => {
          const actor = getActor(assoc.actorId);
          const uc = getUseCase(assoc.useCaseId);
          if (!actor || !uc) return null;
          const isActive = activeElement === assoc.actorId || activeElement === assoc.useCaseId;
          const actorEdgeX = actor.side === 'left' ? actor.x + 30 : actor.x - 30;
          const ucEdgeX = uc.cx - 90;
          return (
            <line
              key={`assoc-${i}`}
              x1={actorEdgeX}
              y1={actor.y}
              x2={ucEdgeX}
              y2={uc.cy}
              stroke={isActive ? '#60a5fa' : '#475569'}
              strokeWidth={isActive ? 2.5 : 1.5}
              opacity={activeElement && !isActive ? 0.3 : 1}
            />
          );
        })}

        {/* Include relationships */}
        {includes.map((inc, i) => {
          const from = getUseCase(inc.from);
          const to = getUseCase(inc.to);
          if (!from || !to) return null;
          const isActive = activeElement === inc.from || activeElement === inc.to;
          const midX = (from.cx + 90 + to.cx - 90) / 2;
          const midY = (from.cy + to.cy) / 2;
          return (
            <g key={`inc-${i}`} opacity={activeElement && !isActive ? 0.3 : 1}>
              <line
                x1={from.cx + 90}
                y1={from.cy}
                x2={to.cx - 90}
                y2={to.cy}
                stroke="#94a3b8"
                strokeWidth={isActive ? 2 : 1.5}
                strokeDasharray="6 3"
                markerEnd="url(#arrow-include)"
              />
              <text x={midX} y={midY - 8} textAnchor="middle" fill="#94a3b8" fontSize="11" fontStyle="italic">
                «include»
              </text>
            </g>
          );
        })}

        {/* Extend relationships */}
        {extends_.map((ext, i) => {
          const from = getUseCase(ext.from);
          const to = getUseCase(ext.to);
          if (!from || !to) return null;
          const isActive = activeElement === ext.from || activeElement === ext.to;
          const midX = (from.cx - 90 + to.cx + 90) / 2;
          const midY = (from.cy + to.cy) / 2;
          return (
            <g key={`ext-${i}`} opacity={activeElement && !isActive ? 0.3 : 1}>
              <line
                x1={from.cx - 90}
                y1={from.cy}
                x2={to.cx + 90}
                y2={to.cy}
                stroke="#a78bfa"
                strokeWidth={isActive ? 2 : 1.5}
                strokeDasharray="6 3"
                markerEnd="url(#arrow-extend)"
              />
              <text x={midX} y={midY - 8} textAnchor="middle" fill="#a78bfa" fontSize="11" fontStyle="italic">
                «extend»
              </text>
            </g>
          );
        })}

        {/* Use Cases (ellipses) */}
        {useCases.map(uc => {
          const isActive = activeElement === uc.id;
          const color = groupColors[uc.group] || '#6b7280';
          return (
            <g
              key={uc.id}
              onClick={() => onSelectElement(uc.id === selectedElement ? null : uc.id)}
              onMouseEnter={() => setHoveredElement(uc.id)}
              onMouseLeave={() => setHoveredElement(null)}
              className="cursor-pointer"
              opacity={activeElement && !isActive ? 0.4 : 1}
            >
              <ellipse
                cx={uc.cx}
                cy={uc.cy}
                rx={90}
                ry={32}
                fill={isActive ? `${color}33` : 'rgba(30, 41, 59, 0.8)'}
                stroke={isActive ? color : `${color}99`}
                strokeWidth={isActive ? 2.5 : 1.5}
                filter={isActive ? 'url(#glow)' : undefined}
              />
              <text
                x={uc.cx}
                y={uc.cy + 5}
                textAnchor="middle"
                fill="white"
                fontSize="12"
                fontWeight={isActive ? 'bold' : 'normal'}
              >
                {uc.label}
              </text>
            </g>
          );
        })}

        {/* Actors */}
        {actors.map(actor => {
          const isActive = activeElement === actor.id;
          return (
            <g
              key={actor.id}
              onClick={() => onSelectElement(actor.id === selectedElement ? null : actor.id)}
              onMouseEnter={() => setHoveredElement(actor.id)}
              onMouseLeave={() => setHoveredElement(null)}
              className="cursor-pointer"
              opacity={activeElement && !isActive ? 0.4 : 1}
            >
              {/* Head */}
              <circle
                cx={actor.x}
                cy={actor.y - 30}
                r={12}
                fill="none"
                stroke={isActive ? '#60a5fa' : '#e2e8f0'}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {/* Body */}
              <line
                x1={actor.x}
                y1={actor.y - 18}
                x2={actor.x}
                y2={actor.y + 10}
                stroke={isActive ? '#60a5fa' : '#e2e8f0'}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {/* Arms */}
              <line
                x1={actor.x - 20}
                y1={actor.y - 8}
                x2={actor.x + 20}
                y2={actor.y - 8}
                stroke={isActive ? '#60a5fa' : '#e2e8f0'}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {/* Left leg */}
              <line
                x1={actor.x}
                y1={actor.y + 10}
                x2={actor.x - 15}
                y2={actor.y + 35}
                stroke={isActive ? '#60a5fa' : '#e2e8f0'}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {/* Right leg */}
              <line
                x1={actor.x}
                y1={actor.y + 10}
                x2={actor.x + 15}
                y2={actor.y + 35}
                stroke={isActive ? '#60a5fa' : '#e2e8f0'}
                strokeWidth={isActive ? 2.5 : 2}
              />
              {/* Label */}
              <text
                x={actor.x}
                y={actor.y + 55}
                textAnchor="middle"
                fill={isActive ? '#60a5fa' : '#e2e8f0'}
                fontSize="13"
                fontWeight={isActive ? 'bold' : 'normal'}
              >
                {actor.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
